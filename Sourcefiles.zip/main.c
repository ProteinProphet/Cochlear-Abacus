/*
 * Cochlear Abacus -- TI-84 Plus CE / CEdev 15.0
 * Entire calculator application. Dependencies: graphx, usbdrvce, keypadc, TI OS.
 * Save as main.c beside the supplied makefile; build with make.
 *
 * One screen: header row 0, history rows 1..8, footer row 9. A slim pixel
 * strip above the footer previews the draft without replacing history.
 * Controls: Y= exits, ENTER sends, DEL backspaces, CLEAR clears the draft,
 * LEFT/RIGHT move its cursor. Typing is always enabled; no composer screen.
 * ALPHA cycles ABC / abc / 123 / SYM. Letter keys follow the calculator's
 * printed alpha legends. In SYM, digit keys 0..9 produce :?!'"@_[];.
 * Operators, parentheses, comma and decimal point also work in 123/SYM.
 * Text sent to the Pi preserves typed case (including :cam:); displayed
 * incoming/outgoing history is uppercase printable ASCII, 24+2 columns.
 *
 * NEW USB CONTRACT, CA-HID v1 (not TI-Innovator, CDC, or a keyboard):
 * Interface 0: vendor-defined HID, unnumbered 64-byte Input/Output reports.
 * EP 0x81 calculator -> Pi; EP 0x02 Pi -> calculator; max packet 64.
 * EP2 OUT was approved because usbdrvce maps endpoint numbers to FIFOs;
 * using EP1 in both directions overwrites FIFO0's direction configuration.
 * Linux hidraw read: 64 bytes. write: a ZERO report-number byte followed
 * by these 64 bytes (65 bytes to write()). Do not detach usbhid.
 * Bytes: 0=0xCA, 1=1, 2=type, 3..4=nonzero message ID (little endian),
 * 5=START(0x80)|END(0x40)|fragment index(0..63), 6=payload length(1..57
 * for DATA, zero for ACK/NACK), 7..63=payload then ZERO padding.
 * Type 1 DATA, 2 ACK, 3 NACK. ACK/NACK echo bytes 3..5 of DATA.
 * Each sender uses stop-and-wait: wait for matching ACK before the next
 * fragment; retry the IDENTICAL report after 500 ms, at most 3 retries.
 * IDs increase per message independently in each direction; reset the USB
 * session before ID reuse. Fragment 0 has START; final fragment has END.
 * Calculator TX max 114 bytes, RX max 1024 bytes per complete message.
 * Receiver ACK means accepted into volatile RAM, NOT RF/LLM delivery.
 * A duplicate of the last accepted DATA is ACKed without appending twice.
 * NACK aborts the message. Malformed traffic is rejected, never truncated.
 * Idle all-zero reports are not protocol packets and must be ignored.
 * Host must service both directions, ACK calculator DATA, bound its queues,
 * and discard all protocol state on USB disconnect/re-enumeration.
 * After ambiguous failure, never replay an entire message automatically.
 * GET_REPORT is an idle snapshot, not a way to dequeue application data.
 * SET_REPORT(Output, ID 0) also works, but use EP2 OUT for normal traffic.
 * No keyboard usages from usb_hid_keys.h apply to this raw-text interface.
 *
 * VID/PID 0451:E008 are the existing TI calculator identifiers (also in
 * CEdev examples), not a newly assigned product identity. Match HID class,
 * product string and CA-HID magic too; old TI bulk relays are incompatible.
 * Pi remains responsible for LoRa headers, RADIO_BUSY, camera and routing.
 * The app writes no files/AppVars; history and pending messages are volatile.
 * Build/static/mock checks do NOT establish physical Linux USB/RF behavior.
 */

#include <tice.h>
#include <keypadc.h>
#include <graphx.h>
/* USB wire structures must have byte alignment, including SDK typedefs. */
#pragma pack(push, 1)
#include <usbdrvce.h>
#pragma pack(pop)
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#define COLS 26
#define ROWS 8
#define WRAP 24
#define TX_MAX 114
#define RX_MAX 1024
#define QUEUE_SIZE 4
#define REPORT_SIZE 64
#define PAYLOAD_SIZE 57
#define DATA 1
#define ACK 2
#define NACK 3
#define START 0x80
#define END 0x40
#define INDEX_MASK 0x3F
#define MAX_RETRIES 3
#define MS(n) ((uint32_t)(n) * UINT32_C(48000))

/* Non-const USB storage deliberately lives in RAM, as required by usbdrvce. */
static uint8_t report_descriptor[] = {
    0x06,0x00,0xFF,       /* USAGE_PAGE (vendor 0xFF00) */
    0x09,0x01,0xA1,0x01, /* USAGE 1, COLLECTION Application */
    0x15,0x00,0x26,0xFF,0x00, /* LOGICAL_MIN 0, MAX 255 */
    0x75,0x08,0x95,0x40, /* 64 fields of 8 bits, no Report ID */
    0x09,0x01,0x81,0x02, /* INPUT (Data,Var,Abs) */
    0x09,0x02,0x91,0x02, /* OUTPUT (Data,Var,Abs) */
    0xC0
};
typedef struct __attribute__((packed)) {
    uint8_t length, type;
    uint16_t version;
    uint8_t country, count, report_type;
    uint16_t report_length;
} hid_descriptor_t;
static struct __attribute__((packed)) {
    usb_configuration_descriptor_t config;
    usb_interface_descriptor_t interface;
    hid_descriptor_t hid;
    usb_endpoint_descriptor_t endpoints[2];
} configuration = {
    {9, USB_CONFIGURATION_DESCRIPTOR, 41, 1, 1, 0, 0x80, 250},
    {9, USB_INTERFACE_DESCRIPTOR, 0, 0, 2, USB_HID_CLASS, 0, 0, 0},
    {9, 0x21, 0x0111, 0, 1, 0x22, sizeof(report_descriptor)},
    {{7, USB_ENDPOINT_DESCRIPTOR, 0x81, USB_INTERRUPT_TRANSFER, 64, 10},
     {7, USB_ENDPOINT_DESCRIPTOR, 0x02, USB_INTERRUPT_TRANSFER, 64, 10}}
};
_Static_assert(sizeof(hid_descriptor_t) == 9, "HID layout");
_Static_assert(sizeof(configuration) == 41, "USB configuration layout");
_Static_assert(sizeof(usb_device_descriptor_t) == 18, "USB device layout");
_Static_assert(sizeof(usb_endpoint_descriptor_t) == 7, "USB endpoint layout");
_Static_assert(sizeof(usb_control_setup_t) == 8, "USB setup layout");
static usb_device_descriptor_t device_descriptor = {
    18, USB_DEVICE_DESCRIPTOR, 0x0200, 0, 0, 0, 64,
    0x0451, 0xE008, 0x0100, 0, 1, 0, 1
};
static usb_string_descriptor_t product = {
    .bLength = sizeof(L"Cochlear Abacus V1"), .bDescriptorType = USB_STRING_DESCRIPTOR,
    .bString = L"Cochlear Abacus V1"
};
static usb_string_descriptor_t languages = {
    .bLength = 4, .bDescriptorType = USB_STRING_DESCRIPTOR,
    .bString = {0x0409}
};
static const usb_string_descriptor_t *strings[] = {&product};
static const usb_configuration_descriptor_t *configurations[] = {
    &configuration.config
};
static const usb_standard_descriptors_t descriptors = {
    &device_descriptor, configurations, &languages, 1, strings
};

static char history[ROWS][COLS + 1], draft[TX_MAX + 1];
static size_t draft_len, cursor;
static uint8_t input_mode;
static bool dirty = true, quit;
static char notice[COLS + 1];
static uint8_t previous_keys[8];

static usb_device_t host;
static usb_endpoint_t ep_in, ep_out;
static bool configured, initialized, restarting, reset_needed;
static bool in_pending, out_pending, control_pending;
static uint32_t in_started, control_started, last_in_time;
static uint8_t in_buffer[REPORT_SIZE], out_buffer[REPORT_SIZE];
static uint8_t control_buffer[REPORT_SIZE], idle_rate, protocol = 1;
static uint8_t receive_queue[QUEUE_SIZE][REPORT_SIZE], rq_head, rq_count;
static uint8_t response[REPORT_SIZE];
static bool response_pending;

typedef struct { char text[TX_MAX + 1]; uint8_t length; } message_t;
static message_t transmit_queue[QUEUE_SIZE];
static uint8_t tq_head, tq_count, tx_offset, tx_fragment, retries;
static uint16_t tx_id = 1;
static uint8_t data_report[REPORT_SIZE];
static bool tx_active, waiting_ack, got_ack;
static uint32_t ack_started;

static char receive_text[RX_MAX + 1];
static size_t receive_length;
static uint16_t receive_id, completed_receive_id;
static uint8_t receive_next, last_received[REPORT_SIZE];
static bool receiving, have_last;
static uint32_t receive_started;

static bool elapsed(uint32_t now, uint32_t start, uint32_t interval) {
    return (uint32_t)(now - start) >= interval; /* Counter wrap-safe. */
}
static void set_notice(const char *s);
static char display_char(unsigned char c) {
    if (c >= 'a' && c <= 'z') return (char)(c - 'a' + 'A');
    return c >= 32 && c <= 126 ? (char)c : ' ';
}
static void clear_history(void) {
    for (uint8_t i = 0; i < ROWS; ++i) {
        memset(history[i], ' ', COLS); history[i][COLS] = '\0';
    }
    dirty = true;
}
static void history_line(char prefix, const char *text, size_t n) {
    memmove(history, history + 1, (ROWS - 1) * sizeof(history[0]));
    memset(history[ROWS - 1], ' ', COLS);
    history[ROWS - 1][0] = prefix;
    for (size_t i = 0; i < n; ++i)
        history[ROWS - 1][i + 2] = display_char((unsigned char)text[i]);
    history[ROWS - 1][COLS] = '\0'; dirty = true;
}
static void append_history(char prefix, const char *text, size_t length) {
    size_t p = 0;
    while (p < length) {
        while (p < length && (text[p] == ' ' || text[p] == '\r')) ++p;
        if (p == length) break;
        if (text[p] == '\n') { ++p; continue; }
        size_t n = 0, split = 0;
        while (n < WRAP && p + n < length && text[p + n] != '\n') {
            if (text[p + n] == ' ') split = n;
            ++n;
        }
        if (n == WRAP && p + n < length && text[p + n] != ' ' &&
            text[p + n] != '\n' && split) n = split;
        history_line(prefix, text + p, n);
        prefix = ' '; p += n;
    }
}
static void set_notice(const char *s) {
    size_t n = strlen(s);
    if (n > COLS) n = COLS;
    /* Status persists in the footer; repeated notices do not scroll chat. */
    if (strlen(notice) == n && !memcmp(notice, s, n)) return;
    memcpy(notice, s, n); notice[n] = '\0';
    dirty = true;
}

/* Explicit ASCII 5x7 glyphs, stored in GraphX's eight-row bitmap format.
 * This avoids TI-OS character codes entirely, including '[' versus theta.
 * Six-pixel cells scaled 2x give exactly 26 columns in 312 LCD pixels. */
#define G(a,b,c,d,e,f,g) {a<<3,b<<3,c<<3,d<<3,e<<3,f<<3,g<<3,0}
static const uint8_t ascii_font[128][8] = {
    [' '] = G(0,0,0,0,0,0,0),       ['!'] = G(4,4,4,4,4,0,4),
    ['"'] = G(10,10,10,0,0,0,0),    ['#'] = G(10,31,10,10,31,10,0),
    ['$'] = G(4,15,20,14,5,30,4),   ['%'] = G(24,25,2,4,8,19,3),
    ['&'] = G(12,18,20,8,21,18,13), ['\''] = G(4,4,8,0,0,0,0),
    ['('] = G(2,4,8,8,8,4,2),      [')'] = G(8,4,2,2,2,4,8),
    ['*'] = G(0,21,14,31,14,21,0), ['+'] = G(0,4,4,31,4,4,0),
    [','] = G(0,0,0,0,4,4,8),      ['-'] = G(0,0,0,31,0,0,0),
    ['.'] = G(0,0,0,0,0,12,12),    ['/'] = G(1,2,2,4,8,8,16),
    ['0'] = G(14,17,19,21,25,17,14), ['1'] = G(4,12,4,4,4,4,14),
    ['2'] = G(14,17,1,2,4,8,31),    ['3'] = G(30,1,1,14,1,1,30),
    ['4'] = G(2,6,10,18,31,2,2),    ['5'] = G(31,16,16,30,1,1,30),
    ['6'] = G(6,8,16,30,17,17,14),  ['7'] = G(31,1,2,4,8,8,8),
    ['8'] = G(14,17,17,14,17,17,14), ['9'] = G(14,17,17,15,1,2,12),
    [':'] = G(0,12,12,0,12,12,0),   [';'] = G(0,12,12,0,4,4,8),
    ['<'] = G(2,4,8,16,8,4,2),     ['='] = G(0,0,31,0,31,0,0),
    ['>'] = G(8,4,2,1,2,4,8),      ['?'] = G(14,17,1,2,4,0,4),
    ['@'] = G(14,17,23,21,23,16,14),
    ['A'] = G(14,17,17,31,17,17,17), ['B'] = G(30,17,17,30,17,17,30),
    ['C'] = G(14,17,16,16,16,17,14), ['D'] = G(30,17,17,17,17,17,30),
    ['E'] = G(31,16,16,30,16,16,31), ['F'] = G(31,16,16,30,16,16,16),
    ['G'] = G(14,17,16,23,17,17,15), ['H'] = G(17,17,17,31,17,17,17),
    ['I'] = G(14,4,4,4,4,4,14),     ['J'] = G(7,2,2,2,2,18,12),
    ['K'] = G(17,18,20,24,20,18,17), ['L'] = G(16,16,16,16,16,16,31),
    ['M'] = G(17,27,21,21,17,17,17), ['N'] = G(17,25,25,21,19,19,17),
    ['O'] = G(14,17,17,17,17,17,14), ['P'] = G(30,17,17,30,16,16,16),
    ['Q'] = G(14,17,17,17,21,18,13), ['R'] = G(30,17,17,30,20,18,17),
    ['S'] = G(15,16,16,14,1,1,30),   ['T'] = G(31,4,4,4,4,4,4),
    ['U'] = G(17,17,17,17,17,17,14), ['V'] = G(17,17,17,17,17,10,4),
    ['W'] = G(17,17,17,21,21,21,10), ['X'] = G(17,17,10,4,10,17,17),
    ['Y'] = G(17,17,10,4,4,4,4),    ['Z'] = G(31,1,2,4,8,16,31),
    ['['] = G(14,8,8,8,8,8,14),     ['\\'] = G(16,8,8,4,2,2,1),
    [']'] = G(14,2,2,2,2,2,14),     ['^'] = G(4,10,17,0,0,0,0),
    ['_'] = G(0,0,0,0,0,0,31),      ['`'] = G(8,4,2,0,0,0,0),
    ['a'] = G(0,0,14,1,15,17,15),   ['b'] = G(16,16,30,17,17,17,30),
    ['c'] = G(0,0,14,17,16,17,14),  ['d'] = G(1,1,15,17,17,17,15),
    ['e'] = G(0,0,14,17,31,16,14),  ['f'] = G(6,9,8,28,8,8,8),
    ['g'] = G(0,15,17,17,15,1,14),  ['h'] = G(16,16,30,17,17,17,17),
    ['i'] = G(4,0,12,4,4,4,14),     ['j'] = G(2,0,6,2,2,18,12),
    ['k'] = G(16,16,18,20,24,20,18), ['l'] = G(12,4,4,4,4,4,14),
    ['m'] = G(0,0,26,21,21,21,17),  ['n'] = G(0,0,30,17,17,17,17),
    ['o'] = G(0,0,14,17,17,17,14),  ['p'] = G(0,30,17,17,30,16,16),
    ['q'] = G(0,15,17,17,15,1,1),   ['r'] = G(0,0,22,25,16,16,16),
    ['s'] = G(0,0,15,16,14,1,30),   ['t'] = G(8,8,28,8,8,9,6),
    ['u'] = G(0,0,17,17,17,19,13),  ['v'] = G(0,0,17,17,17,10,4),
    ['w'] = G(0,0,17,17,21,21,10),  ['x'] = G(0,0,17,10,4,10,17),
    ['y'] = G(0,17,17,17,15,1,14),  ['z'] = G(0,0,31,2,4,8,31),
    ['{'] = G(2,4,4,8,4,4,2),      ['|'] = G(4,4,4,4,4,4,4),
    ['}'] = G(8,4,4,2,4,4,8),      ['~'] = G(0,0,8,21,2,0,0)
};
#undef G

#define DRAFT_COLS 52
static size_t draft_view(char *line) {
    /* Keep an insertion cursor visible even after the final character. */
    size_t start = cursor >= DRAFT_COLS ? cursor - DRAFT_COLS + 1 : 0;
    size_t n = draft_len - start;
    if (n > DRAFT_COLS) n = DRAFT_COLS;
    memcpy(line, draft + start, n); line[n] = '\0';
    return start;
}
static void draw(void) {
    if (!dirty) return;
    dirty = false;
    char line[DRAFT_COLS + 1];
    static const char *const modes[] = {"ABC", "abc", "123", "SYM"};
    gfx_FillScreen(255);
    gfx_SetTextScale(2, 2);
    gfx_PrintStringXY("[====COCHLEAR==ABACUS====]", 4, 2);
    for (uint8_t i = 0; i < ROWS; ++i)
        gfx_PrintStringXY(history[i], 4, 24 + 22 * i);
    snprintf(line, sizeof(line), "[END] %s %u/114 %s", modes[input_mode],
             (unsigned)draft_len, configured && !reset_needed ? "USB" : "OFF");
    /* Two compact footer lines retain controls and a dedicated status view. */
    gfx_SetTextScale(1, 1);
    gfx_PrintStringXY(line, 4, 222);
    gfx_PrintStringXY(notice, 4, 232);
    gfx_SetColor(0);
    gfx_HorizLine_NoClip(4, 20, 312);
    gfx_HorizLine_NoClip(4, 198, 312);
    gfx_HorizLine_NoClip(4, 218, 312);
    size_t start = draft_view(line);
    gfx_SetTextScale(1, 1);
    gfx_PrintStringXY(line, 4, 204);
    gfx_HorizLine_NoClip(4 + (cursor - start) * 6, 213, 5);
    gfx_BlitBuffer(); /* One completed frame; no OS token rendering or flicker. */
}

static void link_failure(const char *why) {
    if (!reset_needed) {
        set_notice(why);
    }
    reset_needed = true;
}
static bool enqueue_text(void) {
    bool nonblank = false;
    for (size_t i = 0; i < draft_len; ++i)
        if (draft[i] != ' ') nonblank = true;
    if (!nonblank) { set_notice("[SYS: EMPTY TEXT]"); return false; }
    if (!configured || reset_needed) {
        set_notice("[SYS: USB OFFLINE]"); return false;
    }
    if (tq_count == QUEUE_SIZE) {
        set_notice("[SYS: QUEUE FULL]"); return false;
    }
    message_t *m = &transmit_queue[(tq_head + tq_count) % QUEUE_SIZE];
    memcpy(m->text, draft, draft_len + 1); m->length = (uint8_t)draft_len;
    ++tq_count; append_history('<', draft, draft_len);
    draft_len = cursor = 0; draft[0] = '\0';
    return true; /* Local echo means queued, not delivered. */
}
static bool pressed(kb_lkey_t key, const uint8_t *edges) {
    return (edges[key >> 8] & (uint8_t)key) != 0;
}
typedef struct { kb_lkey_t key; char letter, number; } keymap_t;
static const keymap_t keymap[] = {
    {kb_KeyMath,'A',0}, {kb_KeyApps,'B',0}, {kb_KeyPrgm,'C',0},
    {kb_KeyRecip,'D',0}, {kb_KeySin,'E',0}, {kb_KeyCos,'F',0},
    {kb_KeyTan,'G',0}, {kb_KeyPower,'H','^'}, {kb_KeySquare,'I',0},
    {kb_KeyComma,'J',','}, {kb_KeyLParen,'K','('}, {kb_KeyRParen,'L',')'},
    {kb_KeyDiv,'M','/'}, {kb_KeyLog,'N',0}, {kb_Key7,'O','7'},
    {kb_Key8,'P','8'}, {kb_Key9,'Q','9'}, {kb_KeyMul,'R','*'},
    {kb_KeyLn,'S',0}, {kb_Key4,'T','4'}, {kb_Key5,'U','5'},
    {kb_Key6,'V','6'}, {kb_KeySub,'W','-'}, {kb_KeySto,'X',0},
    {kb_Key1,'Y','1'}, {kb_Key2,'Z','2'}, {kb_Key3,0,'3'},
    {kb_Key0,' ','0'}, {kb_KeyDecPnt,':','.'}, {kb_KeyChs,'?','-'},
    {kb_KeyAdd,0,'+'}
};
static void scan_keys(void) {
    uint8_t edges[8] = {0};
    kb_Scan();
    for (uint8_t i = 1; i < 8; ++i) {
        uint8_t current = kb_Data[i];
        edges[i] = current & (uint8_t)~previous_keys[i];
        previous_keys[i] = current;
    }
    if (quit) return; /* While F1 is releasing, keep polling but stop editing. */
    if (pressed(kb_KeyYequ, edges)) { quit = true; return; }
    if (pressed(kb_KeyEnter, edges)) {
        (void)enqueue_text();
        dirty = true; return;
    }
    if (pressed(kb_KeyAlpha, edges)) { input_mode = (input_mode + 1) % 4; dirty = true; return; }
    if (pressed(kb_KeyClear, edges)) {
        draft_len = cursor = 0; draft[0] = '\0'; dirty = true; return;
    }
    if (pressed(kb_KeyLeft, edges)) { if (cursor) --cursor; dirty = true; return; }
    if (pressed(kb_KeyRight, edges)) { if (cursor < draft_len) ++cursor; dirty = true; return; }
    if (pressed(kb_KeyDel, edges)) {
        if (cursor) {
            memmove(draft + cursor - 1, draft + cursor, draft_len - cursor + 1);
            --cursor; --draft_len; dirty = true;
        }
        return;
    }
    for (size_t i = 0; i < sizeof(keymap) / sizeof(*keymap); ++i) {
        if (!pressed(keymap[i].key, edges)) continue;
        char c = input_mode < 2 ? keymap[i].letter : keymap[i].number;
        if (input_mode == 1 && c >= 'A' && c <= 'Z') c += 'a' - 'A';
        if (input_mode == 3 && c >= '0' && c <= '9') c = ":?!'\"@_[];"[c - '0'];
        if (!c) return;
        if (draft_len == TX_MAX) { set_notice("[SYS: TEXT TOO LONG]"); return; }
        memmove(draft + cursor + 1, draft + cursor, draft_len - cursor + 1);
        draft[cursor++] = c; ++draft_len; dirty = true; return;
    }
}

static uint16_t message_id(const uint8_t *p) {
    return (uint16_t)p[3] | ((uint16_t)p[4] << 8);
}
static void make_response(const uint8_t *p, uint8_t type) {
    memset(response, 0, REPORT_SIZE);
    response[0] = 0xCA; response[1] = 1; response[2] = type;
    memcpy(response + 3, p + 3, 3); response_pending = true;
    if (type == NACK) {
        receiving = false; receive_length = 0;
        /* A rejected partial message must not block the next START. */
        if (have_last && !(last_received[5] & END)) have_last = false;
    }
}
static void consume_report(const uint8_t *p, uint32_t now) {
    if (p[0] != 0xCA || p[1] != 1 || !message_id(p)) return;
    if (p[6] > PAYLOAD_SIZE) { if (p[2] == DATA) make_response(p, NACK); return; }
    for (size_t i = 7 + p[6]; i < REPORT_SIZE; ++i)
        if (p[i]) { if (p[2] == DATA) make_response(p, NACK); return; }
    if (p[2] == ACK || p[2] == NACK) {
        if (waiting_ack && !p[6] && !memcmp(p + 3, data_report + 3, 3)) {
            if (p[2] == ACK) got_ack = true;
            else link_failure("[SYS: USB NACK; DROPPED]");
        }
        return;
    }
    if (p[2] != DATA) return;
    if (have_last && !memcmp(p, last_received, REPORT_SIZE)) {
        make_response(p, ACK); return;
    }
    uint8_t index = p[5] & INDEX_MASK;
    if (!p[6] || ((p[5] & START) && index)) { make_response(p, NACK); return; }
    if (p[5] & START) {
        if (receiving || message_id(p) <= completed_receive_id) {
            make_response(p, NACK); return;
        }
        receive_length = 0; receive_next = 0;
        receive_id = message_id(p); receiving = true;
    }
    if (!receiving || message_id(p) != receive_id || index != receive_next ||
        receive_length + p[6] > RX_MAX || (index == INDEX_MASK && !(p[5] & END))) {
        make_response(p, NACK); return;
    }
    /* Preserve line breaks, sanitize everything else before it reaches the LCD. */
    for (uint8_t i = 0; i < p[6]; ++i) {
        unsigned char c = p[7 + i];
        receive_text[receive_length++] = c == '\n' ? '\n' : display_char(c);
    }
    receive_text[receive_length] = '\0'; ++receive_next; receive_started = now;
    memcpy(last_received, p, REPORT_SIZE); have_last = true;
    if (p[5] & END) {
        append_history('>', receive_text, receive_length); receiving = false;
        completed_receive_id = receive_id;
    }
    make_response(p, ACK);
}
static void queue_received(const uint8_t *p, size_t n) {
    /* Accept a larger callback length, but queue only the 64-byte report. */
    if (n < REPORT_SIZE) { link_failure("[SYS: BAD USB LENGTH]"); return; }
    if (rq_count == QUEUE_SIZE) { link_failure("[SYS: USB RX OVERFLOW]"); return; }
    memcpy(receive_queue[(rq_head + rq_count) % QUEUE_SIZE], p, REPORT_SIZE); ++rq_count;
}
static usb_error_t out_done(usb_endpoint_t endpoint, usb_transfer_status_t status,
                            size_t transferred, void *unused) {
    (void)endpoint; (void)unused; out_pending = false;
    if (restarting || reset_needed) return USB_SUCCESS;
    if (status == USB_TRANSFER_COMPLETED) queue_received(out_buffer, transferred);
    else link_failure("[SYS: USB RX FAILED]");
    return USB_SUCCESS;
}
static usb_error_t in_done(usb_endpoint_t endpoint, usb_transfer_status_t status,
                           size_t transferred, void *unused) {
    (void)endpoint; (void)unused; in_pending = false;
    if (restarting || reset_needed) return USB_SUCCESS;
    if (status != USB_TRANSFER_COMPLETED || transferred != REPORT_SIZE)
        link_failure("[SYS: USB TX UNKNOWN]");
    else last_in_time = usb_GetCycleCounter();
    return USB_SUCCESS;
}
static usb_error_t control_done(usb_endpoint_t endpoint, usb_transfer_status_t status,
                                size_t transferred, void *is_output) {
    (void)endpoint; control_pending = false;
    if (restarting || reset_needed) return USB_SUCCESS;
    if (status == USB_TRANSFER_COMPLETED && is_output)
        queue_received(control_buffer, transferred);
    /* A host may abort a control read; no application data was sent by it. */
    return USB_SUCCESS;
}
static usb_error_t control_reply(usb_endpoint_t ep, void *buffer, size_t length,
                                 bool output) {
    usb_error_t err = usb_ScheduleTransfer(ep, buffer, length, control_done,
                                         output ? &control_buffer : NULL);
    if (err == USB_SUCCESS) {
        control_pending = true; control_started = usb_GetCycleCounter();
        return USB_IGNORE; /* Only suppress default handling on SUCCESS. */
    }
    return err;
}
static usb_error_t usb_event(usb_event_t event, void *event_data, void *unused) {
    (void)unused;
    if (restarting) return USB_SUCCESS;
    if (event == USB_DEVICE_DISCONNECTED_EVENT || event == USB_DEVICE_DISABLED_EVENT ||
        event == USB_ROLE_CHANGED_EVENT) {
        if (configured) {
            configured = false; link_failure("[SYS: USB LOST; DROPPED]");
        }
        return USB_SUCCESS;
    }
    if (event == USB_HOST_CONFIGURE_EVENT) {
        if (configured) { link_failure("[SYS: USB RECONFIGURED]"); return USB_SUCCESS; }
        const usb_configuration_descriptor_t *cfg = event_data;
        if (!cfg || cfg->bConfigurationValue != 1) return USB_SUCCESS;
        host = usb_FindDevice(NULL, NULL, USB_SKIP_HUBS);
        if (!host) return USB_ERROR_NO_DEVICE;
        ep_in = usb_GetDeviceEndpoint(host, 0x81);
        ep_out = usb_GetDeviceEndpoint(host, 0x02);
        if (!ep_in || !ep_out) return USB_ERROR_FAILED;
        usb_SetEndpointFlags(ep_in, USB_MANUAL_TERMINATE);
        usb_SetEndpointFlags(ep_out, USB_MANUAL_TERMINATE);
        configured = true; dirty = true;
        set_notice("[SYS: USB READY]");
        return USB_SUCCESS;
    }
    if (event != USB_DEFAULT_SETUP_EVENT) return USB_SUCCESS;
    const usb_control_setup_t *s = event_data;
    /* Let usbdrvce perform standard requests, including SET_CONFIGURATION. */
    if (s->bmRequestType == 0x00 && s->bRequest == 0x09 && s->wValue == 0 && configured)
        link_failure("[SYS: USB UNCONFIGURED]");
    if (s->wIndex != 0 || control_pending) return USB_SUCCESS;
    host = usb_FindDevice(NULL, NULL, USB_SKIP_HUBS);
    if (!host) return USB_ERROR_NO_DEVICE;
    usb_endpoint_t ep0 = usb_GetDeviceEndpoint(host, 0);
    if (!ep0) return USB_ERROR_FAILED;
    if (s->bmRequestType == 0x81 && s->bRequest == 0x06) {
        void *p; size_t n;
        if (s->wValue == 0x2200) { p = report_descriptor; n = sizeof(report_descriptor); }
        else if (s->wValue == 0x2100) { p = &configuration.hid; n = sizeof(configuration.hid); }
        else return USB_SUCCESS;
        if (n > s->wLength) n = s->wLength;
        return control_reply(ep0, p, n, false);
    }
    if (s->bmRequestType == 0x21) { /* Host-to-device, class, interface. */
        if (s->bRequest == 0x0A && !s->wLength && !(s->wValue & 0xFF)) {
            idle_rate = s->wValue >> 8;
            return control_reply(ep0, NULL, 0, false); /* SET_IDLE -- Linux fix */
        }
        if (s->bRequest == 0x0B && !s->wLength && s->wValue <= 1) {
            protocol = (uint8_t)s->wValue;
            /* Non-boot vendor HID: report layout does not change. */
            return control_reply(ep0, NULL, 0, false); /* SET_PROTOCOL -- Linux fix */
        }
        if (s->bRequest == 0x09 && s->wValue == 0x0200 && s->wLength == REPORT_SIZE &&
            configured && rq_count < QUEUE_SIZE - 1) {
            /* Reserve a queue slot for this transfer and the armed EP2 OUT. */
            return control_reply(ep0, control_buffer, REPORT_SIZE, true);
        }
    }
    if (s->bmRequestType == 0xA1) {
        if (s->bRequest == 0x02 && !s->wValue && s->wLength == 1) {
            control_buffer[0] = idle_rate;
            return control_reply(ep0, control_buffer, 1, false);
        }
        if (s->bRequest == 0x03 && !s->wValue && s->wLength == 1) {
            control_buffer[0] = protocol;
            return control_reply(ep0, control_buffer, 1, false);
        }
        if (s->bRequest == 0x01 && s->wValue == 0x0100 && s->wLength) {
            memset(control_buffer, 0, sizeof(control_buffer));
            return control_reply(ep0, control_buffer,
                s->wLength < REPORT_SIZE ? s->wLength : REPORT_SIZE, false);
        }
    }
    return USB_SUCCESS; /* Unsupported requests fall through to the driver's stall. */
}

static void reset_session(void) {
    /* Call ONLY AFTER usb_Cleanup: no DMA/callback can still own these buffers. */
    configured = in_pending = out_pending = control_pending = false;
    host = NULL; ep_in = ep_out = NULL;
    rq_head = rq_count = tq_head = tq_count = 0;
    tx_offset = tx_fragment = retries = 0; tx_id = 1;
    tx_active = waiting_ack = got_ack = response_pending = false;
    receiving = have_last = false; receive_length = 0;
    completed_receive_id = 0; last_in_time = 0;
    idle_rate = 0; protocol = 1; reset_needed = false;
}
static bool initialize_usb(void) {
    usb_error_t err = usb_Init(usb_event, NULL, &descriptors, USB_DEFAULT_INIT_FLAGS);
    initialized = true; /* Cleanup is required even if usb_Init failed. */
    if (err == USB_SUCCESS) return true;
    set_notice("[SYS: USB INIT FAILED]");
    return false;
}
static bool send_report(const uint8_t *report, uint32_t now) {
    memcpy(in_buffer, report, REPORT_SIZE);
    usb_error_t err = usb_ScheduleInterruptTransfer(ep_in, in_buffer, REPORT_SIZE, in_done, NULL);
    if (err != USB_SUCCESS) { link_failure("[SYS: USB SCHEDULE FAIL]"); return false; }
    in_pending = true; in_started = now; return true;
}
static void prepare_data(void) {
    const message_t *m = &transmit_queue[tq_head];
    uint8_t n = m->length - tx_offset;
    if (n > PAYLOAD_SIZE) n = PAYLOAD_SIZE;
    memset(data_report, 0, REPORT_SIZE);
    data_report[0] = 0xCA; data_report[1] = 1; data_report[2] = DATA;
    data_report[3] = (uint8_t)tx_id; data_report[4] = tx_id >> 8;
    data_report[5] = tx_fragment | (tx_offset ? 0 : START) |
        (tx_offset + n == m->length ? END : 0);
    data_report[6] = n; memcpy(data_report + 7, m->text + tx_offset, n);
    tx_active = true; retries = 0;
}
static void service_usb(uint32_t now) {
    if ((in_pending && elapsed(now, in_started, MS(2000))) ||
        (control_pending && elapsed(now, control_started, MS(2000)))) {
        link_failure("[SYS: USB STALL; DROPPED]"); return;
    }
    if (!configured || reset_needed) return;
    if (receiving && elapsed(now, receive_started, MS(5000))) {
        link_failure("[SYS: RX TIMEOUT]"); return;
    }
    /* Stop dequeuing DATA while its response is waiting to enter EP1 IN. */
    if (rq_count && !response_pending) {
        consume_report(receive_queue[rq_head], now);
        rq_head = (rq_head + 1) % QUEUE_SIZE; --rq_count;
    }
    if (reset_needed) return;
    /* Reserve a slot for a possibly concurrent SET_REPORT control transfer. */
    if (!out_pending && rq_count < QUEUE_SIZE - (control_pending ? 1 : 0)) {
        usb_error_t err = usb_ScheduleInterruptTransfer(ep_out, out_buffer, REPORT_SIZE, out_done, NULL);
        if (err != USB_SUCCESS) { link_failure("[SYS: USB RX ARM FAIL]"); return; }
        out_pending = true;
    }
    if (in_pending) return;
    if (got_ack) {
        waiting_ack = got_ack = false; tx_active = false;
        tx_offset += data_report[6]; ++tx_fragment;
        if (data_report[5] & END) {
            tq_head = (tq_head + 1) % QUEUE_SIZE; --tq_count;
            tx_offset = tx_fragment = 0;
            if (++tx_id == 0) { link_failure("[SYS: USB SESSION RENEW]"); return; }
        }
    }
    if (response_pending) {
        if (send_report(response, now)) response_pending = false;
        return;
    }
    if (waiting_ack) {
        if (!elapsed(now, ack_started, MS(500))) return;
        if (retries == MAX_RETRIES) {
            link_failure("[SYS: NO ACK; TX UNKNOWN]"); return;
        }
        if (send_report(data_report, now)) { ++retries; ack_started = now; }
        return;
    }
    if (tq_count) {
        if (!tx_active) prepare_data();
        if (send_report(data_report, now)) { waiting_ack = true; ack_started = now; }
    } else if (idle_rate && elapsed(now, last_in_time, MS((uint16_t)idle_rate * 4))) {
        /* Vendor interface has no held keys; its idle state is an empty report. */
        static uint8_t idle_report[REPORT_SIZE];
        send_report(idle_report, now);
    }
}

/* External C entry point: CEdev's startup code resolves this as _main. */
int main(void) {
    clear_history();
    os_DisableCursor(); os_DisableHomeTextBuffer(); os_ClrHomeFull();
    gfx_Begin();
    gfx_SetDrawBuffer();
    gfx_SetFontData(&ascii_font[0][0]);
    gfx_SetFontHeight(8);
    gfx_SetMonospaceFont(6);
    gfx_SetTextFGColor(0);
    gfx_SetTextBGColor(255);
    kb_Scan();
    for (uint8_t i = 1; i < 8; ++i) previous_keys[i] = kb_Data[i];
    bool usb_ok = initialize_usb();
    /* Keep servicing USB until F1 is released, so its held key cannot open
     * the Y= editor immediately after returning to TI-OS. */
    while (!quit || (kb_Data[kb_KeyYequ >> 8] & (uint8_t)kb_KeyYequ)) {
        if (usb_ok) {
            usb_error_t err = usb_HandleEvents();
            if (err != USB_SUCCESS) link_failure("[SYS: USB ERROR; DROPPED]");
            if (!reset_needed) service_usb(usb_GetCycleCounter());
            if (reset_needed) {
                restarting = true;
                usb_Cleanup(); initialized = false;
                reset_session(); restarting = false;
                usb_ok = initialize_usb(); dirty = true;
            }
        }
        scan_keys(); draw(); /* No blocking input/delays; USB always gets serviced. */
    }
    restarting = true;
    if (initialized) usb_Cleanup();
    gfx_End(); /* Restore TI-OS LCD mode only after USB transfers are stopped. */
    os_ClrHomeFull(); os_ForceCmdNoChar();
    return 0;
}
